const Cinema = module.exports
var axios = require('axios')
async function execQuery(qu){
    try{
        var encoded = encodeURIComponent(qu)
        var resp = await axios.get('http://localhost:7200/repositories/cinema?query='+encoded)
        var jsonLst = [];
        for (i in resp.data){
            var jsonel=[]
            for(j in i.head){
                jsonLst[vars[j]] = res[i].vars[j].value;
            }
        }
        return jsonLst;
    } catch(err) {
        return(err);
    }
}
Cinema.listarFilmes = () => {
    const query = `PREFIX : <http://prc.di.uminho.pt/2019/cinema#>
        select * where {
        ?s a :Filme .
        }
        order by desc(?ano) ?tit`;
    return execQuery(query);
}
Cinema.infoFilme = async (id) => {
    const query = `PREFIX : <http://prc.di.uminho.pt/2019/cinema#
        select * where {
        :${id} a :Filme,
        ?s :título ?tit,
           :ano ?ano .
        }
        order by desc(?ano) ?tit`;
    return execQuery(query)
}
Cinema.anosFilmes = async (id) => {
    const query = `PREFIX : <http://prc.di.uminho.pt/2019/cinema#
    select ?ano where {
    :${id} :ano ?ano
    }`;
    return execQuery(query);
}
Cinema.atoresFilmes = async () => {
    const query = `PREFIX : <http://prc.di.uminho.pt/2019/cinema#
    select * where {
    :${id} :temAtor ?a.
    ?a :nome ?nomeAtor.
    }`;
    return execQuery(query)
}
Cinema.generosFilmes = async (id) => {
    const query = `PREFIX : <http://prc.di.uminho.pt/2019/cinema#
    select ?g where {
    :${id} :temGénero ?g.
    }`;
    return execQuery(query)
}
Cinema.infoAtor = async (id) => {
    const query = `PREFIX : <http://prc.di.uminho.pt/2019/cinema#
    select * where {
    :${id} :temAtor ?a.
    ?a :nome ?nomeAtor.
    }`;
    return execQuery(query)
}
Cinema.listarAtores = async () => {
    const query = `PREFIX : <http://prc.di.uminho.pt/2019/cinema#>
    select ?p where {
    ?p a :Pessoa
    }`;
    return execQuery(query)
}
Cinema.filmesAtores = async (id) => {
    const query = `PREFIX : <http://prc.di.uminho.pt/2019/cinema#
    select * where {
    :${id} :temAtor ?a.
    ?a :nome ?nomeAtor.
    }`;
    return execQuery(query)
}
Cinema.listarGeneros = async () => {
    const query = `PREFIX : <http://prc.di.uminho.pt/2019/cinema#
    select ?s where {
    ?s a :Género.
    }`;
    return execQuery(query)
}
Cinema.filmesGeneros = async (id) => {
    const query = `PREFIX : <http://prc.di.uminho.pt/2019/cinema#
    select ?ftit where {
    :${id} :éGéneroDe ?f.
    ?f :título ?ftit.
    }`;
    return execQuery(query)
}