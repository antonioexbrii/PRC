var express = require('express');
var router = express.Router();

var Cinema = require('../controllers/cinema')

/* GET home page. */
router.get('/filmes', async (req,res,next)=>{
    var dados = await Cinema.listarFilmes()
    res.json(dados)
})
router.get('/filmes/:id', async (req,res,next)=>{
    var dados = await Cinema.infoFilme(req.params.id)
    if(dados) res.jsonp(dados)
    else res.status(500).send(`Erro na query ${req.query}`)    
})
router.get('/filmes/:id/anos', async (req,res,next)=>{
    var dados = await Cinema.anosFilmes(req.params.id)
    if(dados) res.jsonp(dados)
    else res.status(500).send(`Erro na query ${req.query}`)    
})
router.get('/filmes/:id/atores', async (req,res,next)=>{
    var dados = await Cinema.atoresFilmes()
    if(dados) res.jsonp(dados)
    else res.status(500).send(`Erro na query ${req.query}`)    
})
router.get('/filmes/:id/generos', async (req,res,next)=>{
    var dados = await Cinema.generosFilmes(req.params.id)
    if(dados) res.jsonp(dados)
    else res.status(500).send(`Erro na query ${req.query}`)    
})
router.get('/atores', async (req,res,next)=>{
    var dados = await Cinema.listarAtores()
    try{
        if(dados) res.jsonp(dados)
        else res.status(500).send(`Erro na query ${req.query}`)
    }catch(err){
        console.log(err)
        console.log(dados)
    }
        
})
router.get('/atores/:id', async (req,res,next)=>{
    var dados = await Cinema.infoAtor(req.params.id)
    if(dados) res.jsonp(dados)
    else res.status(500).send(`Erro na query ${req.query}`)    
})
router.get('/atores/:id/filmes', async (req,res,next)=>{
    var dados = await Cinema.filmesAtores(req.params.id)
    if(dados) res.jsonp(dados)
    else res.status(500).send(`Erro na query ${req.query}`)    
})
router.get('/generos', async (req,res,next)=>{
    var dados = await Cinema.listarGeneros()
    if(dados) res.jsonp(dados)
    else res.status(500).send(`Erro na query ${req.query}`)    
})
router.get('/generos/:id/filmes', async (req,res,next)=>{
    var dados = await Cinema.filmesGeneros(req.params.id)
    if(dados) res.jsonp(dados)
    else res.status(500).send(`Erro na query ${req.query}`)    
})


module.exports = router;
